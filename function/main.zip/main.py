def helloGET(request):
    return 'Hello, World!'